

<?php $__env->startSection('title', 'about'); ?>

<?php $__env->startSection('container'); ?>
	<div class="container">
		<div class="row">
			<div class="col-10">
				<div class="card2 mb-3" style="width: 69rem;">
					<h1 class="titles">Tentang kami</h1>
						<div class="col">
					  <div class="card text-center">
							<div class="card2">		
								<div class="card-body">	
									<p class="card-text"><br>Kelompok 9</p>
								</div>
							
							</div>
							<div class="card2">		
								<div class="card-body">	
									<p class="card-text"><br>Ernerstine Zefanya	11181023 </p>
								</div>
							
							</div>
							<div class="col">
								<div class="card2">		
									<div class="card-body">	
										<p class="card-text"><br>Fajriansyah	11181027</p>
									</div>
								</div>
							</div>
							<div class="col">
								<div class="card2">		
								  <div class="card-body">	
										<p class="card-text"><br>M zul Ikram	11181049</p>
									</div>
								</div>
							</div>
							<div class="col">
								<div class="card2">		
								  <div class="card-body">	
										<p class="card-text"><br>M.RizkyP.	11181063</p>
									</div>
								</div>
							</div>
							<div class="col">
								<div class="card2">		
								  <div class="card-body">	
										<p class="card-text"><br>Pricilia Irene zefania	11181071</p>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
          
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\webuas\resources\views/about.blade.php ENDPATH**/ ?>
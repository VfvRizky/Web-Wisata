@extends('layout/main')

@section('title', 'boking')

@section('container')
  <div class="container">
    <div class="row">
        <div class="col-10">
          <h1 class="titles">Boking</h1>
        </div>
    </div>
  </div>
          
@endsection
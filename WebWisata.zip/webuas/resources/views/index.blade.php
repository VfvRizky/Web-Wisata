@extends('layout/main')

@section('title', 'Wisata.IN')

@section('container')
  <div class="container">
    <div class="row">
        <div class="col-10">
          <h1 class="mt-3">.</h1>
		  <section class="titles">
	<div class="beranda">
    <h1>Wisata.IN</h1>
    <p>Website Travel Sederhana</p>
	</div>
	
	
    <div class="box">

      

      <div class="text">
        <a href="/balikpapan">
          <h3>Balikpapan</h3>
          <p>Berisi tentang Apa sih kota Balikpapan itu</p>
        </a>
      </div>

    </div>

    <div class="box">

      

      <div class="text">
        <a href="/about">
          <h3>About</h3>
          <p>Tentang Profil yang Berkontribusi dalam membuat website sederhana ini</p>
        </a>
      </div>

    </div>

    <div class="box">

      

      <div class="text">
        <a href="/boking">
          <h3>Boking</h3>
          <p>Pemesenan lokasi sesuai jadwal yang sudah diboking</p>
        </a>
      </div>

    </div>
  
        </div>
    </div>
  </div>
      
@endsection
@extends('layout/main')

@section('title', 'balikpapan')

@section('container')
  <div class="center">
    <div class="row">
        <div class="title">
          <h1 class="glow">BALIKPAPAN</h1>
        </div>
    </div>
  </div>
  <div class="container">
    <div class="row">
        <div class="col-10">
           <div class="card2 mb-3" style="width: 69rem;">
          <div class="row g-0">
            <div class="col-md-4">
              
            </div>
            <div class="card text-center">
			  <div class="card-body">
			    
			    	<p class="card-text">Balikpapan adalah sebuah kota di Provinsi Kalimantan Timur yang merupakan 
					gerbang utama menuju ibu kota Indonesia yang baru. Sebagai pusat bisnis dan industri, kota ini 
					memiliki perekonomian terbesar di seluruh Kalimantan, dengan total PDRB mencapai Rp79,65 triliun 
					pada tahun 2016. Kemudian dari sisi kependudukan, Balikpapan adalah kota terbesar kedua di Kalimantan 
					Timur (setelah Kota Samarinda) dengan total penduduk sebanyak 645.727 pada tahun 2018 dan pada tahun 
					2019 berjumlah 655.178 jiwa.<br>Ada beberapa hikayat populer yang menceritakan asal usul kota yang berada 
					di pesisir timur Kalimantan ini, yaitu :</p>

			    	<p class="card-text"></p>

			    	<p class="card-text"></p>

			    	<p class="card-text"></p>

			  </div>
				<div class="row row-cols-1 row-cols-md-2 g-4">
  <div class="col">
    <div class="card3">
    
      <div class="card-body">
        
        <p class="card-text">Yang pertama asal nama Balikpapan adalah karena sebuah kejadian yang terjadi pada tahun 1739, 
		sewaktu dibawah Pemerintahan Sultan Muhammad Idris dari Kerajaan Kutai, yang memerintahkan kepada pemukim-pemukim 
		di sepanjang Teluk Balikpapan untuk menyumbang bahan bangunan guna pembangunan istana baru di Kutai lama. Sumbangan 
		tersebut ditentukan berupa penyerahan sebanyak 1000 lembar papan yang diikat menjadi sebuah rakit yang dibawa ke 
		Kutai Lama melalui sepanjang pantai. Setibanya di Kutai lama, ternyata ada 10 keping papan yang kurang (terlepas 
		selama dalam perjalanan) dan hasil dari pencarian menemukan bahwa 10 keping papan tersebut terhanyut dan timbul disuatu 
		tempat yang sekarang bernama "Jenebora". Dari peristiwa inilah nama Balikpapan itu diberikan (dalam istilah bahasa Kutai 
		"Baliklah - papan itu" atau papan yang kembali yang tidak mau ikut disumbangkan). </p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card3">
      
      <div class="card-body">
        
        <p class="card-text">Menurut legenda dari orang-orang suku Pasir Balik atau lazim disebut Suku Pasir Kuleng, maka secara 
		turun menurun telah dihikayatkan tentang asal mula nama "Negeri Balikpapan". Orang-orang suku Pasir Balik yang bermukim 
		di sepanjang pantai teluk Balikpapan adalah berasal dari keturunan kakek dan nenek yang bernama " KAYUN KULENG dan PAPAN 
		AYUN ". Oleh keturunannya kampung nelayan yang terletak di Teluk Balikpapan itu diberi nama "KULENG - PAPAN" atau artinya 
		"BALIK - PAPAN" (Dalam bahasa Pasir, Kuleng artinya Balik dan Papan artinya Papan) dan diperkirakan nama negeri Balikpapan 
		itu adalah sekitar tahun 1527. </p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card3">
    
      <div class="card-body">
        
        <p class="card-text">Dalam legenda lain juga disebutkan asal usul Balikpapan, yaitu dari seorang putri yang dilepas 
		oleh ayahnya seorang raja yang tidak ingin putrinya tersebut jatuh ke tangan musuh. Sang putri yang masih balita 
		diikat di atas beberapa keping papan dalam keadaan terbaring. Karena terbawa arus dan diterpa gelombang, papan tersebut 
		terbalik. Ketika papan tersebut terdampar di tepi pantai ditemukan oleh seorang nelayan dan begitu dibalik ternyata 
		terdapat seorang putri yang masih dalam keadaan terikat. Konon putri tersebut bernama Putri Petung yang berasal dari 
		Kerajaan Pasir. Sehingga daerah tempat ditemukannya dinamakan Balikpapan.</p>
      </div>
    </div>
  </div>
  <div class="col">
    <div class="card3">
     
      <div class="card-body">
        
        <p class="card-text">Dalam legenda lain juga disebutkan asal usul Balikpapan, yaitu dari seorang putri yang dilepas 
		oleh ayahnya seorang raja yang tidak ingin putrinya tersebut jatuh ke tangan musuh. Sang putri yang masih balita diikat 
		di atas beberapa keping papan dalam keadaan terbaring. Karena terbawa arus dan diterpa gelombang, papan tersebut terbalik. 
		Ketika papan tersebut terdampar di tepi pantai ditemukan oleh seorang nelayan dan begitu dibalik ternyata terdapat seorang 
		putri yang masih dalam keadaan terikat. Konon putri tersebut bernama Putri Petung yang berasal dari Kerajaan Pasir. Sehingga 
		daerah tempat ditemukannya dinamakan Balikpapan.<br>
		Hari jadi kota Balikpapan adalah tanggal 10 Februari 1897. Penetapan tanggal ini merupakan hasil Seminar Sejarah Balikpapan 
		pada tanggal 1 Desember 1984. Tanggal 10 Februari 1897 ini adalah tanggal pengeboran minyak pertama di Balikpapan yang 
		dilakukan oleh perusahaan Mathilda sebagai realisasi dari pasal-pasal kerja sama antara J.H. Menten dengan Mr. Adams dari 
		Firma Samuel dan Co.</p>
      </div>

      <div class="container">
  <h1 class="neon">Be Diffrent<br>From the others</h1>
</div>


    </div>
  </div>
</div>

			</div>

		</div>
     
				
        </div>       
          
      </div>
    </div>
  </div>
          
@endsection